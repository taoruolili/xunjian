<?php

namespace app\http\middleware;

class AdminWare
{
    public function handle($request, \Closure $next)
    {
    }
}
